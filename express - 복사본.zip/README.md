##library
-express: 백엔드 프레임워크
-cors:다른 도메인에서 제공하는 리소스에 엑세스 할 수 있도록 하는 기능
-json: json 파싱
-body-parser: 클라이언트로 부터 전달된 body 받기
-nodemon: 저장시 서버 새로고침
